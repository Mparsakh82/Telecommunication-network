// سرور سیگنالینگ VoIP (WebRTC)
//  - HTTP  روی پورت 8080  → برای تست روی خود کامپیوتر (http://localhost:8080)
//  - HTTPS روی پورت 8443  → برای گوشی (میکروفون در گوشی فقط با HTTPS کار می‌کند)
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { WebSocketServer } = require('ws');

const HTTP_PORT = 8080;
const HTTPS_PORT = 8443;

const page = (req, res) => {
  fs.readFile(path.join(__dirname, 'public', 'index.html'), (err, data) => {
    if (err) { res.writeHead(500); return res.end('index.html not found'); }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(data);
  });
};

// ---------- سیگنالینگ ----------
const wss = new WebSocketServer({ noServer: true });
const stations = new Map(); // name -> ws

const broadcastUsers = () => {
  const msg = JSON.stringify({ type: 'users', users: [...stations.keys()] });
  stations.forEach(ws => ws.send(msg));
};

wss.on('connection', ws => {
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m.type === 'register') {
      if (stations.has(m.name)) return ws.send(JSON.stringify({ type: 'taken' }));
      ws.name = m.name; stations.set(m.name, ws); broadcastUsers();
    } else if (m.type === 'signal') {
      const target = stations.get(m.to);
      if (target) target.send(JSON.stringify({ type: 'signal', from: ws.name, data: m.data }));
      console.log(`${ws.name} -> ${m.to}: ${m.data.kind}`);
    }
  });
  ws.on('close', () => { if (ws.name) { stations.delete(ws.name); broadcastUsers(); } });
});

const attach = (srv, label, port) => {
  srv.on('upgrade', (req, socket, head) => wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req)));
  srv.on('error', err => {
    if (err.code === 'EADDRINUSE') console.error(`\n[${label}] پورت ${port} اشغال است. سرور قبلی را ببندید:  pkill -f "node server.js"\n`);
    else console.error(`[${label}]`, err.message);
  });
};

// ---------- HTTP ----------
const httpServer = http.createServer(page);
attach(httpServer, 'HTTP', HTTP_PORT);
httpServer.listen(HTTP_PORT, '0.0.0.0', () => {
  console.log(`\nHTTP  (تست روی همین کامپیوتر):  http://localhost:${HTTP_PORT}`);
});

// ---------- HTTPS (برای گوشی) ----------
try {
  const selfsigned = require('selfsigned');
  // هر بار گواهی تازه با IPهای فعلی ساخته می‌شود (iPhone گواهی بدون SAN را کاملاً رد می‌کند)
  const ips = Object.values(os.networkInterfaces()).flat()
    .filter(i => i.family === 'IPv4').map(i => i.address);
  const altNames = [{ type: 2, value: 'localhost' }, ...ips.map(ip => ({ type: 7, ip }))];
  const p = selfsigned.generate([{ name: 'commonName', value: 'voip-lab' }], {
    days: 365, keySize: 2048, algorithm: 'sha256',
    extensions: [
      { name: 'basicConstraints', cA: false },
      { name: 'keyUsage', digitalSignature: true, keyEncipherment: true },
      { name: 'extKeyUsage', serverAuth: true },
      { name: 'subjectAltName', altNames }
    ]
  });
  const cert = { private: p.private, cert: p.cert };
  const httpsServer = https.createServer({ key: cert.private, cert: cert.cert }, page);
  attach(httpsServer, 'HTTPS', HTTPS_PORT);
  httpsServer.listen(HTTPS_PORT, '0.0.0.0', () => {
    console.log('HTTPS (برای گوشی):');
    Object.values(os.networkInterfaces()).flat()
      .filter(i => i.family === 'IPv4' && !i.internal)
      .forEach(i => console.log(`  https://${i.address}:${HTTPS_PORT}`));
    console.log('');
  });
} catch (e) {
  console.error('ساخت HTTPS ناموفق بود (HTTP همچنان کار می‌کند):', e.message);
}